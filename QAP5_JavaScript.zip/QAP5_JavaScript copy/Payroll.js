fetch('Payroll_Data.json')
  .then(response => response.json())
  .then(data => {
    data.forEach(employee => {
      console.log(getFullName(employee));
      console.log(getTenure(employee));
      console.log(getSalary(employee));
    });
  })
  .catch(error => {
    console.error(error);
  });

  function getFullName(employee) {
    return `${employee.firstname} ${employee.lastname}`;
  }

  function getTenure(employee) {    
    return `${employee.firstname} has been with us for ${new Date().getFullYear() - 
      new Date(employee.startdate).getFullYear()} years.`; 
  }

  function getSalary(employee){
    return employee.salary;
  }

  function getSalary(employee){
    return `${employee.firstname} has a yearly salary of ${employee.salary}.`;
  }
